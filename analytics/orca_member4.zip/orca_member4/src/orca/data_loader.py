"""Table loader for the ORCA dataset (OrionDataset.xlsx or a folder of processed CSV files)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd

EXCEL_SHEET_NAME_LIMIT = 31


def load_table(source: str | Path, name: str) -> pd.DataFrame:
    """Load table `name` (e.g. 'aquaculture_sites') from an .xlsx workbook or a CSV directory."""
    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"Data source not found: {path}")
    if path.is_file():
        if path.suffix.lower() not in {".xlsx", ".xlsm"}:
            raise ValueError(f"Unsupported data file type: {path.suffix}")
        return pd.read_excel(path, sheet_name=name[:EXCEL_SHEET_NAME_LIMIT])
    csv_path = path / f"{name}.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Table '{name}' not found in {path} (expected {csv_path.name})")
    return pd.read_csv(csv_path)
