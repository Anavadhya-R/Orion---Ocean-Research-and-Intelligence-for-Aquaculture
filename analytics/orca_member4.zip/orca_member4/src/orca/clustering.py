"""K-means clustering of aquaculture sites on environmental and production features."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.impute import SimpleImputer
from sklearn.metrics import silhouette_samples, silhouette_score
from sklearn.preprocessing import StandardScaler

from .data_loader import load_table

# feature column -> (label when above average, label when below average)
FEATURE_LABELS: dict[str, tuple[str, str]] = {
    "average_temperature_c": ("warmer water", "colder water"),
    "average_salinity_psu": ("higher salinity", "lower salinity"),
    "average_dissolved_oxygen_mg_l": ("higher dissolved oxygen", "lower dissolved oxygen"),
    "water_depth_m": ("deeper sites", "shallower sites"),
    "water_quality_index": ("higher water quality index", "lower water quality index"),
    "environmental_risk_score": ("higher environmental risk", "lower environmental risk"),
    "capacity_log": ("higher production capacity", "lower production capacity"),
    "mean_monthly_production_tonnes": ("higher recorded monthly production", "lower recorded monthly production"),
    "mean_mortality_rate_percent": ("higher mortality", "lower mortality"),
}
ENV_FEATURES = [
    "average_temperature_c",
    "average_salinity_psu",
    "average_dissolved_oxygen_mg_l",
    "water_depth_m",
    "water_quality_index",
    "environmental_risk_score",
]
PRODUCTION_FEATURES = ["capacity_log", "mean_monthly_production_tonnes", "mean_mortality_rate_percent"]
CAPACITY_COLUMN = "estimated_production_capacity_tonnes_year"
Z_THRESHOLD = 0.5


@dataclass
class ClusterResult:
    k: int
    silhouette: float
    silhouette_by_k: dict[int, float]
    features_used: list[str]
    features_dropped: dict[str, str]
    assignments: pd.DataFrame
    summary: pd.DataFrame


def build_site_features(sites: pd.DataFrame, production: pd.DataFrame | None = None) -> pd.DataFrame:
    """Return one row per site with numeric environmental and production features (NaN where unavailable)."""
    if "site_id" not in sites.columns:
        raise ValueError("sites table must contain 'site_id'")
    frame = sites.drop_duplicates("site_id").copy()
    for col in ENV_FEATURES + [CAPACITY_COLUMN]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce") if col in frame.columns else np.nan
    frame["capacity_log"] = np.log1p(frame[CAPACITY_COLUMN].where(frame[CAPACITY_COLUMN] >= 0))
    frame["mean_monthly_production_tonnes"] = np.nan
    frame["mean_mortality_rate_percent"] = np.nan
    if production is not None and not production.empty and "site_id" in production.columns:
        prod = production.copy()
        for col in ("production_tonnes", "mortality_rate_percent"):
            prod[col] = pd.to_numeric(prod[col], errors="coerce") if col in prod.columns else np.nan
        agg = prod.groupby("site_id").agg(
            mean_monthly_production_tonnes=("production_tonnes", "mean"),
            mean_mortality_rate_percent=("mortality_rate_percent", "mean"),
        )
        frame = frame.drop(columns=list(agg.columns)).merge(agg, how="left", left_on="site_id", right_index=True)
    return frame.reset_index(drop=True)


def select_features(frame: pd.DataFrame, candidates: list[str], min_coverage: float) -> tuple[list[str], dict[str, str]]:
    used: list[str] = []
    dropped: dict[str, str] = {}
    for col in candidates:
        if col not in frame.columns:
            dropped[col] = "column missing"
            continue
        coverage = frame[col].notna().mean()
        if coverage < min_coverage:
            dropped[col] = f"coverage {coverage:.0%} below minimum {min_coverage:.0%}"
        elif frame[col].nunique(dropna=True) < 2:
            dropped[col] = "constant or empty"
        else:
            used.append(col)
    return used, dropped


def _interpret(z_scores: pd.Series, n: int, share: float, sil: float) -> str:
    strong = z_scores[z_scores.abs() >= Z_THRESHOLD].sort_values(key=np.abs, ascending=False).head(4)
    parts = [FEATURE_LABELS[f][0 if z > 0 else 1] for f, z in strong.items()]
    profile = ", ".join(parts) if parts else "close to the overall average on all features"
    quality = "strong" if sil > 0.5 else "reasonable" if sil > 0.25 else "weak"
    return f"{n} sites ({share:.0%}): {profile}. Cluster separation is {quality} (mean silhouette {sil:.2f})."


def run_clustering(
    frame: pd.DataFrame,
    candidates: list[str] | None = None,
    k: int | None = None,
    k_range: tuple[int, int] = (2, 8),
    min_coverage: float = 0.5,
    seed: int = 42,
    silhouette_sample_size: int = 5000,
) -> ClusterResult:
    """Standardise features, pick k by silhouette (or use fixed k), fit K-means and describe each cluster."""
    candidates = candidates or ENV_FEATURES + PRODUCTION_FEATURES
    features, dropped = select_features(frame, candidates, min_coverage)
    if len(features) < 2:
        raise ValueError(f"At least 2 usable features are required; usable={features}, dropped={dropped}")
    data = frame.loc[frame[features].notna().any(axis=1)].reset_index(drop=True)
    n = len(data)
    if n < 3:
        raise ValueError("At least 3 records with feature data are required for clustering")

    values = data[features].replace([np.inf, -np.inf], np.nan)
    imputed_count = values.isna().sum(axis=1)
    scaled = StandardScaler().fit_transform(SimpleImputer(strategy="median").fit_transform(values))

    if k is not None:
        if not 2 <= k < n:
            raise ValueError(f"k must satisfy 2 <= k < {n}; got {k}")
        k_values = [k]
    else:
        lo, hi = max(2, k_range[0]), min(k_range[1], n - 1)
        if lo > hi:
            raise ValueError(f"Invalid k range {k_range} for {n} records")
        k_values = list(range(lo, hi + 1))

    sample = silhouette_sample_size if n > silhouette_sample_size else None
    sil_by_k: dict[int, float] = {}
    for kv in k_values:
        labels_kv = KMeans(n_clusters=kv, n_init=10, random_state=seed).fit_predict(scaled)
        sil_by_k[kv] = float(silhouette_score(scaled, labels_kv, sample_size=sample, random_state=seed))
    best_k = max(sil_by_k, key=sil_by_k.get)

    labels = KMeans(n_clusters=best_k, n_init=10, random_state=seed).fit_predict(scaled)
    idx = np.arange(n) if sample is None else np.random.default_rng(seed).choice(n, sample, replace=False)
    sil_samples = pd.Series(silhouette_samples(scaled[idx], labels[idx]), index=idx)
    cluster_sil = sil_samples.groupby(labels[idx]).mean()

    z_frame = pd.DataFrame(scaled, columns=features)
    rows = []
    for cid in sorted(set(labels)):
        mask = labels == cid
        sil = float(cluster_sil.get(cid, np.nan))
        row = {
            "cluster_id": int(cid),
            "n_sites": int(mask.sum()),
            "share_pct": round(100 * mask.mean(), 1),
            "mean_silhouette": round(sil, 3),
        }
        for col in features:
            row[f"median_{col}"] = round(float(data.loc[mask, col].median()), 3)
        for ctx in ("site_type", "ocean_basin"):
            if ctx in data.columns and data.loc[mask, ctx].notna().any():
                top = data.loc[mask, ctx].value_counts(normalize=True)
                row[f"top_{ctx}"] = f"{top.index[0]} ({top.iloc[0]:.0%})"
        row["interpretation"] = _interpret(z_frame.loc[mask].mean(), int(mask.sum()), mask.mean(), sil)
        rows.append(row)

    keep = [c for c in ("site_id", "site_name", "latitude", "longitude", "ocean_basin", "site_type") if c in data.columns]
    assignments = data[keep].copy()
    assignments["cluster_id"] = labels
    assignments["n_imputed_features"] = imputed_count.to_numpy()
    return ClusterResult(
        k=int(best_k),
        silhouette=float(sil_samples.mean()),
        silhouette_by_k=sil_by_k,
        features_used=features,
        features_dropped=dropped,
        assignments=assignments,
        summary=pd.DataFrame(rows),
    )


def cluster_sites(
    source: str | Path,
    require_production: bool = False,
    **kwargs,
) -> ClusterResult:
    """Load sites (+ fish_production when available) from `source` and cluster them."""
    sites = load_table(source, "aquaculture_sites")
    try:
        production = load_table(source, "fish_production")
    except (FileNotFoundError, ValueError):
        production = None
    frame = build_site_features(sites, production)
    if require_production:
        frame = frame.loc[frame["mean_monthly_production_tonnes"].notna()].reset_index(drop=True)
    return run_clustering(frame, **kwargs)


def main() -> None:
    parser = argparse.ArgumentParser(description="K-means clustering of ORCA aquaculture sites")
    parser.add_argument("--source", required=True, help="OrionDataset.xlsx or folder of processed CSV files")
    parser.add_argument("--out", default="outputs/clustering", help="output directory")
    parser.add_argument("--k", type=int, default=None, help="fixed number of clusters (default: best silhouette)")
    parser.add_argument("--k-min", type=int, default=2)
    parser.add_argument("--k-max", type=int, default=8)
    parser.add_argument("--min-coverage", type=float, default=0.5)
    parser.add_argument("--production-only", action="store_true", help="only sites with fish_production records")
    args = parser.parse_args()

    result = cluster_sites(
        args.source,
        require_production=args.production_only,
        k=args.k,
        k_range=(args.k_min, args.k_max),
        min_coverage=args.min_coverage,
    )
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    result.assignments.to_csv(out / "cluster_assignments.csv", index=False)
    result.summary.to_csv(out / "cluster_summary.csv", index=False)
    print(f"k={result.k}  silhouette={result.silhouette:.3f}  by_k={ {k: round(v, 3) for k, v in result.silhouette_by_k.items()} }")
    print(f"features used: {result.features_used}")
    for feat, reason in result.features_dropped.items():
        print(f"feature dropped: {feat} ({reason})")
    for _, row in result.summary.iterrows():
        print(f"Cluster {row['cluster_id']}: {row['interpretation']}")


if __name__ == "__main__":
    main()
