"""Species-to-Site Habitat Match Score: PRELIMINARY SCREENING ONLY, not a guarantee of farming suitability.

Method: each environmental factor with a documented species requirement is scored 0-100 and the
overall score is the unweighted mean of the factors that could be scored.
- temperature, salinity, depth: 100 inside the species' [min, max] range (marine_species columns);
  outside the range the score falls linearly to 0 at one range-width beyond the nearest limit.
- dissolved oxygen: 100 when site oxygen >= species minimum need, otherwise proportional (need is only
  available for species listed in species_environment_compatibility explanations).
Species ranges in the dataset are labelled simulated/approximate and are not authoritative.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .data_loader import load_table

DISCLAIMER = "PRELIMINARY SCREENING TOOL - NOT A GUARANTEE OF FARMING SUITABILITY"
DATA_CAVEAT = "Species requirements and site data in this dataset are simulated/approximate; verify with expert and field data."
TOLERANCE_WIDTHS = 1.0
MIN_FACTORS = 2
CLASS_BANDS = [(80.0, "Excellent"), (60.0, "Good")]  # compatibility_class cut points observed in the dataset
LOW_CLASS = "Fair/Poor (below 60)"
CONCERN_STATUSES = {"VU": "Vulnerable", "EN": "Endangered", "CR": "Critically Endangered"}

SITE_ALIASES = {
    "temperature_c": ["temperature_c", "average_temperature_c", "water_temperature_c"],
    "salinity_psu": ["salinity_psu", "average_salinity_psu"],
    "dissolved_oxygen_mg_l": ["dissolved_oxygen_mg_l", "average_dissolved_oxygen_mg_l"],
    "depth_m": ["depth_m", "water_depth_m"],
    "environmental_risk_score": ["environmental_risk_score"],
    "water_quality": ["water_quality_score", "water_quality_index"],
}
NON_NEGATIVE = {"salinity_psu", "dissolved_oxygen_mg_l", "depth_m"}
FACTORS = {
    "temperature": ("temperature_c", "min_temperature_c", "max_temperature_c", "C"),
    "salinity": ("salinity_psu", "min_salinity_psu", "max_salinity_psu", "PSU"),
    "depth": ("depth_m", "min_depth_m", "max_depth_m", "m"),
}
_OXYGEN_PATTERN = re.compile(r"oxygen\s+[\d.]+\s*mg/L\s+vs\s+need\s+([\d.]+)")


def oxygen_requirements(compatibility: pd.DataFrame) -> pd.Series:
    """Species minimum dissolved oxygen (mg/L) parsed from the compatibility explanation text."""
    if not {"species_id", "explanation"}.issubset(compatibility.columns):
        return pd.Series(dtype=float)
    need = pd.to_numeric(compatibility["explanation"].astype(str).str.extract(_OXYGEN_PATTERN)[0], errors="coerce")
    return need.groupby(compatibility["species_id"]).first().dropna()


def risk_reference(sites: pd.DataFrame) -> dict[str, float]:
    """Dataset-relative cut points: top-quartile environmental risk and bottom-quartile water quality."""
    ref: dict[str, float] = {}
    clean, _ = zip(*[normalise_site(r) for r in sites.to_dict("records")]) if len(sites) else ((), ())
    frame = pd.DataFrame(clean)
    if "environmental_risk_score" in frame and frame["environmental_risk_score"].notna().any():
        ref["risk_p75"] = float(frame["environmental_risk_score"].quantile(0.75))
    if "water_quality" in frame and frame["water_quality"].notna().any():
        ref["water_quality_p25"] = float(frame["water_quality"].quantile(0.25))
    return ref


def normalise_site(site: dict | pd.Series) -> tuple[dict[str, float], list[str]]:
    """Map site fields to canonical names; invalid/non-numeric values become NaN with an issue note."""
    record = dict(site)
    clean: dict[str, float] = {}
    issues: list[str] = []
    for canon, aliases in SITE_ALIASES.items():
        value = np.nan
        for alias in aliases:
            if alias in record and pd.notna(record[alias]):
                try:
                    value = float(record[alias])
                except (TypeError, ValueError):
                    issues.append(f"{alias}: non-numeric value {record[alias]!r} ignored")
                    continue
                if not np.isfinite(value) or (canon in NON_NEGATIVE and value < 0):
                    issues.append(f"{alias}: invalid value {value} ignored")
                    value = np.nan
                    continue
                break
        clean[canon] = value
    return clean, issues


def range_score(value: float, low: float, high: float) -> float | None:
    """100 inside [low, high]; linear decline to 0 at TOLERANCE_WIDTHS * (high - low) outside. None if unscorable."""
    if any(pd.isna(v) for v in (value, low, high)) or low > high:
        return None
    if low <= value <= high:
        return 100.0
    deviation = low - value if value < low else value - high
    width = high - low
    if width <= 0:
        return 0.0
    return round(max(0.0, 100.0 * (1.0 - deviation / (TOLERANCE_WIDTHS * width))), 1)


def classify(score: float | None) -> str:
    if score is None or pd.isna(score):
        return "Insufficient data"
    for cut, label in CLASS_BANDS:
        if score >= cut:
            return label
    return LOW_CLASS


def score_pair(
    species: dict | pd.Series,
    site: dict[str, float],
    oxygen_need: float | None = None,
    reference: dict[str, float] | None = None,
) -> dict:
    """Score one species against one normalised site."""
    species = dict(species)
    scores: dict[str, float] = {}
    details: list[str] = []
    missing: list[str] = []
    warnings: list[str] = []

    for name, (site_col, lo_col, hi_col, unit) in FACTORS.items():
        value, lo, hi = site.get(site_col, np.nan), pd.to_numeric(species.get(lo_col), errors="coerce"), pd.to_numeric(species.get(hi_col), errors="coerce")
        if pd.isna(value):
            missing.append(f"site {name}")
            continue
        if pd.isna(lo) or pd.isna(hi) or lo > hi:
            missing.append(f"species {name} range")
            continue
        s = range_score(value, lo, hi)
        scores[name] = s
        if s == 100.0:
            details.append(f"{name}: {value:g} {unit} within {lo:g}-{hi:g} ({s:.0f})")
        else:
            direction = "below" if value < lo else "above"
            warnings.append(f"{name} {value:g} {unit} is {direction} species range {lo:g}-{hi:g}")
            details.append(f"{name}: {value:g} {unit} {direction} {lo:g}-{hi:g} ({s:.0f})")

    oxygen = site.get("dissolved_oxygen_mg_l", np.nan)
    if pd.isna(oxygen):
        missing.append("site dissolved oxygen")
    elif oxygen_need is None or pd.isna(oxygen_need):
        missing.append("species oxygen requirement")
    else:
        s = 100.0 if oxygen >= oxygen_need else round(100.0 * oxygen / oxygen_need, 1) if oxygen_need > 0 else 0.0
        scores["oxygen"] = s
        if s < 100.0:
            warnings.append(f"dissolved oxygen {oxygen:g} mg/L is below species need {oxygen_need:g} mg/L")
        details.append(f"oxygen: {oxygen:g} mg/L vs need {oxygen_need:g} ({s:.0f})")

    score = round(float(np.mean(list(scores.values()))), 1) if len(scores) >= MIN_FACTORS else None
    if score is None:
        warnings.append(f"fewer than {MIN_FACTORS} factors could be scored; no score given")

    potential = str(species.get("aquaculture_potential", ""))
    if potential == "Not_suitable":
        warnings.append("species catalogue lists aquaculture potential as Not_suitable")
    status = str(species.get("conservation_status", ""))
    if status in CONCERN_STATUSES:
        warnings.append(f"conservation status {status} ({CONCERN_STATUSES[status]}); verify regulations")
    reference = reference or {}
    risk, quality = site.get("environmental_risk_score", np.nan), site.get("water_quality", np.nan)
    if pd.notna(risk) and "risk_p75" in reference and risk >= reference["risk_p75"]:
        warnings.append(f"site environmental risk score {risk:g} is in the highest quartile of the reference data (>= {reference['risk_p75']:g})")
    if pd.notna(quality) and "water_quality_p25" in reference and quality <= reference["water_quality_p25"]:
        warnings.append(f"site water quality {quality:g} is in the lowest quartile of the reference data (<= {reference['water_quality_p25']:g})")

    return {
        "species_id": species.get("species_id"),
        "common_name": species.get("common_name"),
        "score": score,
        "suitability_class": classify(score),
        "temperature_score": scores.get("temperature"),
        "salinity_score": scores.get("salinity"),
        "depth_score": scores.get("depth"),
        "oxygen_score": scores.get("oxygen"),
        "factors_scored": len(scores),
        "contributing_factors": "; ".join(details),
        "missing_data": "; ".join(missing),
        "warnings": "; ".join(warnings),
        "label": DISCLAIMER,
    }


def score_site(
    site: dict | pd.Series,
    species: pd.DataFrame,
    oxygen_needs: pd.Series | None = None,
    reference: dict[str, float] | None = None,
    species_ids: list[str] | None = None,
    top_n: int | None = None,
) -> tuple[pd.DataFrame, list[str]]:
    """Score every (or selected) species for one site. Returns (ranked results, site-level data issues)."""
    clean, issues = normalise_site(site)
    if all(pd.isna(clean[c]) for c in ("temperature_c", "salinity_psu", "depth_m", "dissolved_oxygen_mg_l")):
        issues.append("no usable environmental values for this site")
    pool = species if species_ids is None else species[species["species_id"].isin(species_ids)]
    needs = oxygen_needs if oxygen_needs is not None else pd.Series(dtype=float)
    rows = [score_pair(r, clean, needs.get(r.get("species_id")), reference) for r in pool.to_dict("records")]
    result = pd.DataFrame(rows)
    if result.empty:
        return result, issues
    result = result.sort_values("score", ascending=False, na_position="last").reset_index(drop=True)
    return (result.head(top_n) if top_n else result), issues


def format_report(site_label: str, results: pd.DataFrame, issues: list[str], top_n: int = 10) -> str:
    lines = [DISCLAIMER, DATA_CAVEAT, f"Site: {site_label}"]
    lines += [f"Site data issue: {i}" for i in issues]
    for _, r in results.head(top_n).iterrows():
        score = "n/a" if pd.isna(r["score"]) else f"{r['score']:.1f}"
        lines.append(f"\n{r['species_id']} {r['common_name']}: {score} ({r['suitability_class']}), {r['factors_scored']} factors scored")
        lines.append(f"  Factors: {r['contributing_factors'] or 'none'}")
        lines.append(f"  Missing data: {r['missing_data'] or 'none'}")
        lines.append(f"  Warnings: {r['warnings'] or 'none'}")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="ORCA species-to-site habitat match (preliminary screening)")
    parser.add_argument("--source", required=True, help="OrionDataset.xlsx or folder of processed CSV files")
    parser.add_argument("--site-id", help="site_id (S####) or habitat_id (H#####)")
    parser.add_argument("--temperature-c", type=float)
    parser.add_argument("--salinity-psu", type=float)
    parser.add_argument("--oxygen-mg-l", type=float)
    parser.add_argument("--depth-m", type=float)
    parser.add_argument("--species-id", action="append", help="restrict to species (repeatable)")
    parser.add_argument("--top", type=int, default=10)
    parser.add_argument("--out", help="optional CSV path for full results")
    args = parser.parse_args()

    species = load_table(args.source, "marine_species")
    sites = load_table(args.source, "aquaculture_sites")
    try:
        needs = oxygen_requirements(load_table(args.source, "species_environment_compatibility"))
    except (FileNotFoundError, ValueError):
        needs = pd.Series(dtype=float)
    reference = risk_reference(sites)

    manual = {"temperature_c": args.temperature_c, "salinity_psu": args.salinity_psu,
              "dissolved_oxygen_mg_l": args.oxygen_mg_l, "depth_m": args.depth_m}
    if args.site_id:
        table, key = (sites, "site_id") if args.site_id.startswith("S") else (load_table(args.source, "habitat_suitability"), "habitat_id")
        match = table[table[key] == args.site_id]
        if match.empty:
            raise SystemExit(f"{key} {args.site_id} not found")
        record, label = match.iloc[0].to_dict(), args.site_id
    elif any(v is not None for v in manual.values()):
        record, label = {k: v for k, v in manual.items() if v is not None}, "manual input"
    else:
        raise SystemExit("Provide --site-id or at least one of --temperature-c/--salinity-psu/--oxygen-mg-l/--depth-m")

    results, issues = score_site(record, species, needs, reference, args.species_id)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        results.to_csv(args.out, index=False)
    print(format_report(label, results, issues, args.top))


if __name__ == "__main__":
    main()
