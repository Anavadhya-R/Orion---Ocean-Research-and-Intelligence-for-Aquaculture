#!/usr/bin/env bash
# Creates the Orion HDFS folder hierarchy and uploads all datasets.
# Run from the package root:  bash scripts/setup_hdfs.sh
set -euo pipefail

BASE=/orion
RAW_DATASETS="marine_species species_occurrences ocean_conditions aquaculture_sites \
habitat_suitability species_environment_compatibility fish_production \
finance_transactions resource_inventory dashboard_kpis"

echo "Creating HDFS directories..."
for d in $RAW_DATASETS; do
  hdfs dfs -mkdir -p $BASE/raw/$d
done
hdfs dfs -mkdir -p $BASE/cleaned/ocean_conditions
hdfs dfs -mkdir -p $BASE/reference
hdfs dfs -mkdir -p $BASE/output

echo "Uploading raw datasets..."
for d in $RAW_DATASETS; do
  hdfs dfs -put -f data/raw/$d.csv $BASE/raw/$d/
done

echo "Uploading cleaned ocean file and reference docs..."
hdfs dfs -put -f data/cleaned/ocean_conditions_cleaned.csv $BASE/cleaned/ocean_conditions/
hdfs dfs -put -f data/reference/data_dictionary.csv data/reference/dataset_summary.csv $BASE/reference/

echo "Verification:"
hdfs dfs -ls -R $BASE
hdfs dfs -du -h $BASE
