#!/usr/bin/env bash
# Simulates MapReduce locally (map | sort | reduce) - no Hadoop needed.
set -euo pipefail
for f in data/raw/ocean_conditions.csv data/cleaned/ocean_conditions_cleaned.csv; do
  echo "== $f"
  python3 mapreduce/mapper.py < "$f" | sort -k1,1 | python3 mapreduce/reducer.py
done
