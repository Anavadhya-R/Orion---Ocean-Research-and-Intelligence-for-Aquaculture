#!/usr/bin/env bash
# Runs the regional aggregation job with Hadoop Streaming.
# Usage: bash scripts/run_mapreduce.sh [raw|cleaned]     (default: raw)
set -euo pipefail

STAGE=${1:-raw}
if [ "$STAGE" = "cleaned" ]; then
  INPUT=/orion/cleaned/ocean_conditions/ocean_conditions_cleaned.csv
else
  INPUT=/orion/raw/ocean_conditions/ocean_conditions.csv
fi
OUTPUT=/orion/output/basin_summary_$STAGE

# Locate the streaming jar (override with STREAMING_JAR=... if needed)
JAR=${STREAMING_JAR:-$(find "${HADOOP_HOME:-/usr/local/hadoop}" -name 'hadoop-streaming*.jar' 2>/dev/null | head -1)}
[ -n "$JAR" ] || { echo "hadoop-streaming jar not found; set STREAMING_JAR"; exit 1; }

hdfs dfs -rm -r -f "$OUTPUT"

hadoop jar "$JAR" \
  -D mapreduce.job.name="orion-basin-aggregation-$STAGE" \
  -files mapreduce/mapper.py,mapreduce/reducer.py \
  -mapper "python3 mapper.py" \
  -reducer "python3 reducer.py" \
  -input "$INPUT" \
  -output "$OUTPUT"

echo; echo "Result (basin, records, avg SST C, avg salinity PSU, avg O2 mg/L, avg chlorophyll mg/m3):"
hdfs dfs -cat "$OUTPUT/part-*"
