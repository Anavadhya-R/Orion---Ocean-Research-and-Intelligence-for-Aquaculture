# Orion – Member 1: Hadoop & Data Storage

Deliverable: working HDFS storage and a MapReduce processing demonstration.

## 1. Package contents

```
data/raw/        10 raw CSV datasets (converted from OrionDataset.xlsx, one CSV per sheet)
data/cleaned/    ocean_conditions_cleaned.csv  (output of the Spark cleaning step)
data/reference/  data_dictionary.csv, dataset_summary.csv
mapreduce/       mapper.py, reducer.py   (regional aggregation by ocean basin)
scripts/         setup_hdfs.sh, run_mapreduce.sh, test_local.sh
docs/            expected_output_raw.tsv, expected_output_cleaned.tsv
```

## 2. Data sources and formats

All data comes from a single collected workbook, `OrionDataset.xlsx` (10 sheets).
The data is **simulated / synthetic** (flagged by `is_synthetic`, `is_simulated`
or `data_origin` columns); species names are real taxa but their ranges are
approximate and not authoritative.

Format: UTF-8 CSV, comma separated, one header row, dates as `YYYY-MM-DD`,
empty cell = null.

| Dataset | Domain | Rows | Cols | Size (bytes) | Purpose |
|---|---|---|---|---|---|
| marine_species | Marine / fisheries | 130 | 18 | 51,358 | Species catalogue and details |
| species_occurrences | Marine environment | 15,814 | 13 | 1,917,792 | Occurrence points for global map |
| ocean_conditions | Marine environment | 21,996 | 16 | 2,270,716 | Global ocean measurements (Spark cleaning demo) |
| aquaculture_sites | Fisheries | 1,000 | 18 | 156,473 | Aquaculture site management |
| habitat_suitability | Marine / ML | 10,600 | 18 | 1,111,370 | Clustering and site recommendation |
| species_environment_compatibility | Marine / fisheries | 10,500 | 10 | 2,182,270 | Species-to-habitat matching scores |
| fish_production | Fisheries | 7,279 | 13 | 675,766 | Monthly production analytics |
| finance_transactions | Economic | 56,270 | 10 | 6,597,477 | Expenses, cash flow |
| resource_inventory | Economic | 3,354 | 11 | 426,815 | Feed, equipment, seed stock |
| dashboard_kpis | Economic | 5,699 | 14 | 819,000 | Aggregated KPIs for dashboards |

Column-level documentation: `data/reference/data_dictionary.csv`.
Row, null and duplicate counts: `data/reference/dataset_summary.csv`.

Data quality: only `ocean_conditions` (4,260 null cells in 3,954 rows) and
`marine_species` (130 null cells) contain nulls. No dataset has duplicate rows.
`ocean_conditions_cleaned.csv` has 0 nulls and is the "after" file of the
Spark cleaning demo (`ocean_conditions.csv` is the "before" file).

## 3. HDFS storage organization

```
/orion
├── raw/
│   ├── marine_species/marine_species.csv
│   ├── species_occurrences/species_occurrences.csv
│   ├── ocean_conditions/ocean_conditions.csv
│   ├── aquaculture_sites/aquaculture_sites.csv
│   ├── habitat_suitability/habitat_suitability.csv
│   ├── species_environment_compatibility/species_environment_compatibility.csv
│   ├── fish_production/fish_production.csv
│   ├── finance_transactions/finance_transactions.csv
│   ├── resource_inventory/resource_inventory.csv
│   └── dashboard_kpis/dashboard_kpis.csv
├── cleaned/
│   └── ocean_conditions/ocean_conditions_cleaned.csv
├── reference/
│   ├── data_dictionary.csv
│   └── dataset_summary.csv
└── output/                       (MapReduce / Spark results)
```

Each dataset has its own folder so it can be used directly as a Hadoop/Spark
input directory. Raw and cleaned data are kept apart so the before/after
comparison stays clear.

Load it with:

```bash
bash scripts/setup_hdfs.sh
```

## 4. MapReduce demonstration: regional aggregation

**Task:** for each `ocean_basin` (Arctic, Atlantic, Indian, Pacific, Southern)
in `ocean_conditions`, compute the record count and the average sea surface
temperature, salinity, dissolved oxygen and chlorophyll-a.

- **Mapper** (`mapper.py`): reads the CSV, finds columns from the header, emits
  `basin <TAB> sst,salinity,oxygen,chlorophyll`. Null or invalid values are
  left empty.
- **Shuffle/sort:** Hadoop groups all lines of the same basin onto one reducer.
- **Reducer** (`reducer.py`): sums values per basin, ignoring nulls per metric,
  and prints `basin, records, avg_sst_c, avg_salinity_psu, avg_oxygen_mg_l,
  avg_chlorophyll_mg_m3`.

Run it:

```bash
bash scripts/run_mapreduce.sh raw       # before cleaning
bash scripts/run_mapreduce.sh cleaned   # after cleaning
# no Hadoop? simulate locally:
bash scripts/test_local.sh
```

Expected result on the raw file (also in `docs/expected_output_raw.tsv`):

| Basin | Records | Avg SST (°C) | Avg salinity (PSU) | Avg O2 (mg/L) | Avg chlorophyll (mg/m³) |
|---|---|---|---|---|---|
| Arctic | 2,161 | 1.777 | 31.516 | 10.026 | 3.071 |
| Atlantic | 6,004 | 19.075 | 35.187 | 7.022 | 1.449 |
| Indian | 4,539 | 25.484 | 34.965 | 6.129 | 0.532 |
| Pacific | 7,186 | 20.432 | 33.849 | 6.863 | 1.671 |
| Southern | 2,106 | -0.872 | 33.244 | 10.496 | 2.946 |

The cleaned file gives slightly different oxygen, salinity and chlorophyll
averages (`docs/expected_output_cleaned.tsv`), because the nulls were filled
during cleaning. The record counts are identical (21,996 rows in both).
These values were checked against a pandas `groupby`.

## 5. Requirements

Hadoop 3.x with HDFS running, Python 3 on all worker nodes, and the
`hadoop-streaming` jar (auto-detected under `$HADOOP_HOME`, or set
`STREAMING_JAR`).
