#!/usr/bin/env python3
"""Mapper: regional (ocean basin) aggregation of ocean_conditions.csv.

Input : CSV lines from ocean_conditions (raw or cleaned).
Output: <ocean_basin> \t <sst>,<salinity>,<oxygen>,<chlorophyll>
        (a field is left empty when the source value is null)
"""
import sys
import csv

COLS = ["sea_surface_temperature_c", "salinity_psu",
        "dissolved_oxygen_mg_l", "chlorophyll_a_mg_m3"]

idx = None
for row in csv.reader(sys.stdin):
    if not row:
        continue
    if row[0] == "measurement_id":          # header line -> learn column positions
        idx = {name: i for i, name in enumerate(row)}
        continue
    if idx is None:                          # data seen before any header: skip
        continue
    basin = row[idx["ocean_basin"]].strip()
    if not basin:
        continue
    vals = []
    for c in COLS:
        v = row[idx[c]].strip()
        try:
            float(v)
        except ValueError:
            v = ""                           # null / bad value
        vals.append(v)
    print("%s\t%s" % (basin, ",".join(vals)))
