#!/usr/bin/env python3
"""Reducer: per-basin record count and averages (nulls ignored per metric).

Input : <ocean_basin> \t v1,v2,v3,v4   (sorted by key by Hadoop)
Output: basin, records, avg_sst_c, avg_salinity_psu, avg_oxygen_mg_l, avg_chlorophyll_mg_m3
"""
import sys

N = 4


def emit(basin, n, sums, cnts):
    avgs = ["%.3f" % (sums[i] / cnts[i]) if cnts[i] else "NA" for i in range(N)]
    print("\t".join([basin, str(n)] + avgs))


cur, n = None, 0
sums, cnts = [0.0] * N, [0] * N
for line in sys.stdin:
    line = line.rstrip("\n")
    if not line:
        continue
    basin, vals = line.split("\t", 1)
    if basin != cur:
        if cur is not None:
            emit(cur, n, sums, cnts)
        cur, n = basin, 0
        sums, cnts = [0.0] * N, [0] * N
    n += 1
    for i, v in enumerate(vals.split(",")):
        if v != "":
            sums[i] += float(v)
            cnts[i] += 1
if cur is not None:
    emit(cur, n, sums, cnts)
